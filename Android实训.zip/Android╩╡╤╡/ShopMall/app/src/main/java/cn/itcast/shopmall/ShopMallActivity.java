package cn.itcast.shopmall;

import android.app.Activity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import cn.itcast.shopmall.database.SQLiteHelper;


public class ShopMallActivity extends Activity{
    private ListView mListView;
    SQLiteHelper mSQLiteHelper;
    //商品名称与价格数据集合
    private String[] titles={"手提电脑", "苹果手机", "羽绒服", "卫衣", "耳机", "鼠标","鞋子", "键盘", "橙子", "苹果", "西瓜"};
    private  String[] prices={
            "5800元", "5000元", "1300元", "350" + "元", "1000元", "99元","1350元", "699元", "15元/kg","10元/kg", "5元/kg"
    };
    //图片数据集合
    private int[] icons={R.drawable.computer, R.drawable.iphone, R.drawable.
            yrf, R.drawable.wy, R.drawable.airpods, R.drawable.sb, R.drawable.aj, R.drawable.jp, R.drawable.orange, R.drawable.apple, R.drawable.xg};
    private android.view.LayoutInflater LayoutInflater;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_shopmall);
        Button shopcar=(Button) findViewById(R.id.shopcar);
        mListView=(ListView) findViewById(R.id.lv);//初始化ListView控件
        MybaseAdapter mAdapter =new MybaseAdapter();
        mSQLiteHelper = new SQLiteHelper(this);
        mListView.setAdapter(mAdapter);
        shopcar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(ShopMallActivity.this, ShopMalllistActivity.class);
                startActivityForResult(intent,1);
            }
        });
        initData();
    }
    protected void initData(){ }
    class MybaseAdapter extends BaseAdapter {
            @Override
            public int getCount() { //获取item的总数
                return titles.length;//返回ListView Item条目的总数
            }
            @Override
            public Object getItem(int position) {
                return titles[position];//返回Item的数据对象
            }
            @Override
            public long getItemId(int position) {
                return position; //返回Item的id
            }
            //得到Item的View视图
            class ViewHolder {
                TextView title, price;
                ImageView iv;
                Button shop;

            }
            //得到list_item的View视图
            @Override
            public View getView(final int position, View convertView, ViewGroup parent) {
                ViewHolder holder = null;
                if (convertView == null) {
                    //将list_item.xml.文件找出来并转换成View对象
                    convertView = View.inflate(ShopMallActivity.this, R.layout.shopmall_item, null);
                    holder = new ViewHolder();
                    holder.title =  convertView.findViewById(R.id.title);
                    holder.price = convertView.findViewById(R.id.price);
                    holder.iv =  convertView.findViewById(R.id.iv);
                    holder.shop = convertView.findViewById(R.id.shop);
                    convertView.setTag(holder);
                } else {
                    //通过getTag方法获取缓存在convertView对象中的ViewHolder
                    holder = (ViewHolder) convertView.getTag();
                }
                //点击加入按钮shop
                holder.shop.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        boolean list = mSQLiteHelper.insertData(titles[position],prices[position],icons[position]);
                        if(list){
                            Toast.makeText(ShopMallActivity.this,"加入成功",Toast.LENGTH_SHORT).show();
                        }else {
                            Toast.makeText(ShopMallActivity.this,"加入失败",Toast.LENGTH_SHORT).show();
                        }

                    }
                });
                holder.title.setText(titles[position]);
                holder.price.setText(prices[position]);
                holder.iv.setBackgroundResource(icons[position]);
                return convertView;
            }
        }
    }
