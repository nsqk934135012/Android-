package cn.itcast.shopmall;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;

import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.List;

import cn.itcast.shopmall.adapter.ShopMallAdapter;
import cn.itcast.shopmall.bean.ShopMallBean;
import cn.itcast.shopmall.database.SQLiteHelper;


public class ShopMalllistActivity extends AppCompatActivity {
    ListView listView;
    Button mButton;
    List<ShopMallBean> list;
    SQLiteHelper mSQLiteHelper;
    ShopMallAdapter adapter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_shopmalllist);
        //用于显示记录列表
        listView=(ListView) findViewById(R.id.listview);
        mButton =(Button) findViewById(R.id.clear) ;
        initData();
    }
    protected void initData(){
        mSQLiteHelper=new SQLiteHelper(this);
        showQueryData();
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                ShopMallBean shopmallBean=list.get(position);
                Intent intent=new Intent(ShopMalllistActivity.this, ShopMallActivity.class);
                intent.putExtra("id",shopmallBean.getId());
                intent.putExtra("title",shopmallBean.getShopMallTitle());
                intent.putExtra("price",shopmallBean.getShopMallPrice());
                ShopMalllistActivity.this.startActivityForResult(intent,1);
            }
        });
        listView.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> parent, View view, final int position, long id) {
                AlertDialog dialog;
                AlertDialog.Builder builder=new AlertDialog.Builder(ShopMalllistActivity.this).setMessage("是否删除商品？")
                        .setPositiveButton("确定", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                ShopMallBean shopmallBean = list.get(position);
                                if (mSQLiteHelper.deleteData(shopmallBean.getId())) {
                                    list.remove(position);
                                    adapter.notifyDataSetChanged();
                                    Toast.makeText(ShopMalllistActivity.this, "删除成功", Toast.LENGTH_SHORT).show();
                                }
                            }
                        }).setNegativeButton("取消", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                dialog.dismiss();
                            }
                        });
                dialog=builder.create();
                dialog.show();
                return true;
            }
        });
        //clear清除全部数据的按钮
        mButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (mSQLiteHelper.deleteDataAll()) {
                    list.clear();
                    adapter.notifyDataSetChanged();
                    Intent intent = new Intent(ShopMalllistActivity.this, ShopMalllistActivity.class)
                            .setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK);
                    startActivity(intent);
                }
            }
        });
    }
    private void showQueryData(){
        if (list!=null){
            list.clear();
        }
        //从数据库中查询数据
        list=mSQLiteHelper.query();
        adapter=new ShopMallAdapter(this , list);
        listView.setAdapter(adapter);
    }
    //重写会掉showQueryData方法并重新获取数据库中已有的数据显示到记录列表
    @Override
    protected  void onActivityResult(int requestCode,int resultCode,Intent data){
        super.onActivityResult(requestCode,resultCode,data);
        if(requestCode==1 && resultCode==2){
            showQueryData();
        }
    }
}
