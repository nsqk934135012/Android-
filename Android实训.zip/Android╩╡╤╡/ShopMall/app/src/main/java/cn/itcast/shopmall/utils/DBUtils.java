package cn.itcast.shopmall.utils;

public class DBUtils {
    public static final String DATABASE_NAME="ShopMall";//数据库名
    public static final String DATABASE_TABLE="shopmall";//表名
    public static final int DATABASE_VERION=1;
    //数据库表中的列名
    public static final String SHOPMALL_ID="id";
    public static final String SHOPMALL_TITLE="title";
    public static final String SHOPMALL_PRICE="price";
}
